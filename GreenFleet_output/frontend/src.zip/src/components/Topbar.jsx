import React, { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { Bell, ChevronDown, LogOut, User as UserIcon, Menu, Settings } from 'lucide-react'
import { useAuth } from '../context/AuthContext.jsx'
import Avatar from './Avatar.jsx'
import { getNotifications, markNotificationRead, markAllNotificationsRead } from '../data/api.js'

const PORTAL_HOME = {
  staff:     '/staff/dashboard',
  transport: '/transport/dashboard',
  system:    '/admin/dashboard',
}

export default function Topbar({ title, breadcrumb, onMenuToggle }) {
  const { user, portal, switchPortal, logout, allowedPortals } = useAuth()
  const navigate = useNavigate()
  const [menuOpen,       setMenuOpen]       = useState(false)
  const [notifOpen,      setNotifOpen]      = useState(false)
  const [notifications,  setNotifications]  = useState([])
  const [unreadCount,    setUnreadCount]    = useState(0)

  const fetchNotifs = useCallback(async () => {
    try {
      const data = await getNotifications()
      const list = Array.isArray(data) ? data : []
      setNotifications(list.slice(0, 8))
      setUnreadCount(list.filter((n) => !n.is_read).length)
    } catch { /* silent */ }
  }, [])

  useEffect(() => {
    fetchNotifs()
    const id = setInterval(fetchNotifs, 30_000)
    return () => clearInterval(id)
  }, [fetchNotifs])

  async function handleMarkRead(id) {
    try {
      await markNotificationRead(id)
      setNotifications((p) => p.map((n) => n.id === id ? { ...n, is_read: true } : n))
      setUnreadCount((c) => Math.max(0, c - 1))
    } catch {}
  }

  async function handleMarkAllRead() {
    try {
      await markAllNotificationsRead()
      setNotifications((p) => p.map((n) => ({ ...n, is_read: true })))
      setUnreadCount(0)
    } catch {}
  }

  async function handleLogout() {
    try { await logout() } catch {}
    window.location.href = '/login'
  }

  function goPortal(next) {
    switchPortal(next)
    setMenuOpen(false)
    window.location.href = PORTAL_HOME[next] || '/staff/dashboard'
  }

  const displayName = user
    ? `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username
    : '—'
  const userRole = user?.role?.name || user?.role || ''
  const notifRoute =
    portal === 'transport' ? '/transport/notifications' :
    portal === 'system'    ? '/admin/notifications'    :
    '/staff/notifications'

  return (
    <header className="h-14 bg-surface border-b border-border-subtle flex items-center justify-between px-4 md:px-5 sticky top-0 z-30">
      {/* Left — hamburger + breadcrumb/title */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onMenuToggle}
          className="md:hidden p-1.5 -ml-1 rounded-lg hover:bg-surface-muted text-ink-600 shrink-0 transition-colors"
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>
        <div className="min-w-0">
          {breadcrumb && (
            <p className="text-2xs text-ink-300 uppercase tracking-wider leading-none mb-0.5 truncate">
              {breadcrumb}
            </p>
          )}
          <h1 className="text-base font-semibold text-ink-900 leading-tight truncate">{title}</h1>
        </div>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-1 shrink-0">

        {/* Bell */}
        <div className="relative">
          <button
            onClick={() => { setNotifOpen((o) => !o); setMenuOpen(false) }}
            className="relative p-2 text-ink-400 hover:text-ink-900 rounded-lg hover:bg-surface-muted transition-colors"
            aria-label="Notifications"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 min-w-[15px] h-[15px] px-[3px] rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center leading-none">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>

          {notifOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setNotifOpen(false)} />
              <div className="absolute right-0 mt-1.5 w-80 bg-surface border border-border-subtle rounded-card shadow-card-md z-20 overflow-hidden animate-fade-up">
                <div className="flex items-center justify-between px-4 py-3 border-b border-border-subtle">
                  <span className="text-sm font-semibold text-ink-900">Notifications</span>
                  {unreadCount > 0 && (
                    <button onClick={handleMarkAllRead} className="text-xs text-brand-green hover:underline">
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="max-h-72 overflow-y-auto divide-y divide-border-subtle scrollbar-thin">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-8 text-center text-sm text-ink-400">
                      No notifications yet
                    </div>
                  ) : (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => !n.is_read && handleMarkRead(n.id)}
                        className={`flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors hover:bg-surface-muted ${!n.is_read ? 'bg-brand-green-50' : ''}`}
                      >
                        <span className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${!n.is_read ? 'bg-brand-green' : 'bg-ink-200'}`} />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-ink-900 leading-snug">{n.title}</p>
                          <p className="text-xs text-ink-500 mt-0.5 line-clamp-2">{n.message}</p>
                          <p className="text-2xs text-ink-300 mt-1">
                            {new Date(n.created_at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                <div className="px-4 py-2.5 border-t border-border-subtle text-center">
                  <button
                    onClick={() => { setNotifOpen(false); navigate(notifRoute) }}
                    className="text-xs text-brand-green hover:underline"
                  >
                    View all
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Profile */}
        <div className="relative ml-1">
          <button
            onClick={() => { setMenuOpen((o) => !o); setNotifOpen(false) }}
            className="flex items-center gap-2 py-1.5 px-2 rounded-lg hover:bg-surface-muted transition-colors"
            aria-label="Profile menu"
          >
            <Avatar name={displayName} size={28} />
            <div className="hidden sm:block text-left">
              <p className="text-sm font-medium text-ink-900 leading-tight">{displayName}</p>
              {userRole && <p className="text-2xs text-ink-400 leading-tight">{userRole}</p>}
            </div>
            <ChevronDown size={14} className="text-ink-400 hidden sm:block" />
          </button>

          {menuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
              <div className="absolute right-0 mt-1.5 w-52 bg-surface border border-border-subtle rounded-card shadow-card-md z-20 py-1 overflow-hidden animate-fade-up">
                {/* Portal switcher */}
                {allowedPortals.length > 1 && (
                  <div className="px-3 py-2 border-b border-border-subtle mb-1">
                    <p className="text-2xs text-ink-300 uppercase tracking-wider mb-1.5 px-0.5">Switch portal</p>
                    {allowedPortals.map((p) => (
                      <button
                        key={p}
                        onClick={() => goPortal(p)}
                        className={[
                          'w-full text-left text-sm rounded-lg px-2 py-1.5 mb-0.5 transition-colors',
                          portal === p
                            ? 'bg-brand-green-100 text-brand-green font-medium'
                            : 'hover:bg-surface-muted text-ink-700',
                        ].join(' ')}
                      >
                        {p === 'system' ? 'Admin' : p.charAt(0).toUpperCase() + p.slice(1)} Portal
                      </button>
                    ))}
                  </div>
                )}
                <button
                  onClick={() => { setMenuOpen(false); navigate('/staff/profile') }}
                  className="w-full flex items-center gap-2.5 text-sm px-3 py-2 hover:bg-surface-muted text-ink-700 transition-colors"
                >
                  <UserIcon size={15} className="text-ink-400" /> Profile
                </button>
                <button
                  onClick={() => { setMenuOpen(false); navigate('/admin/settings') }}
                  className="w-full flex items-center gap-2.5 text-sm px-3 py-2 hover:bg-surface-muted text-ink-700 transition-colors"
                >
                  <Settings size={15} className="text-ink-400" /> Settings
                </button>
                <div className="border-t border-border-subtle my-1" />
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2.5 text-sm px-3 py-2 hover:bg-red-50 text-red-600 transition-colors"
                >
                  <LogOut size={15} /> Log out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
