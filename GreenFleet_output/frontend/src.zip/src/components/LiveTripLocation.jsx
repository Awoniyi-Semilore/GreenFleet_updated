import React, {
  useEffect,
  useRef,
  useState,
} from 'react'

import {
  MapPin,
  Navigation,
  LocateFixed,
  AlertCircle,
  RefreshCw,
} from 'lucide-react'

import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  Circle,
  useMap,
} from 'react-leaflet'

import L from 'leaflet'

import {
  updateTripLocation,
  getTripLocation,
  stopTripLocation,
} from '../data/api.js'


/*
 * ============================================================
 * LEAFLET VEHICLE ICON
 * ============================================================
 */

const vehicleIcon = new L.Icon({
  iconUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',

  iconRetinaUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',

  shadowUrl:
    'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',

  iconSize: [25, 41],

  iconAnchor: [12, 41],

  popupAnchor: [1, -34],

  shadowSize: [41, 41],
})


/*
 * ============================================================
 * MAP DEBUG / RESIZE HANDLER
 * ============================================================
 *
 * Leaflet can calculate the wrong dimensions when a map
 * appears after conditional rendering or when its parent
 * changes size.
 *
 * invalidateSize() tells Leaflet:
 *
 * "Recalculate the actual size of your container."
 *
 * This is particularly important for:
 *
 * - responsive layouts
 * - cards
 * - conditional rendering
 * - loading -> map transitions
 * - browser resizing
 * - sidebar/layout changes
 */

function MapReadyHandler() {
  const map = useMap()

  useEffect(() => {
    console.log(
      '[LiveTripLocation][MAP] Map instance mounted.'
    )

    const logMapSize = (source) => {
      const container =
        map.getContainer()

      const rect =
        container?.getBoundingClientRect()

      console.log(
        `[LiveTripLocation][MAP] invalidateSize triggered by: ${source}`,
        {
          containerWidth:
            rect?.width,

          containerHeight:
            rect?.height,

          mapSize:
            map.getSize(),

          zoom:
            map.getZoom(),

          center:
            map.getCenter(),
        }
      )

      map.invalidateSize({
        animate: false,
      })
    }


    /*
     * Initial correction.
     *
     * requestAnimationFrame allows the browser to
     * finish painting the container before Leaflet
     * measures it.
     */
    const frame =
      requestAnimationFrame(() => {
        logMapSize(
          'initial render'
        )
      })


    /*
     * Run again shortly after mounting.
     *
     * This catches cases where the parent/card has
     * finished resizing after the first frame.
     */
    const timeout =
      setTimeout(() => {
        logMapSize(
          'delayed render'
        )
      }, 300)


    /*
     * Watch the map container for size changes.
     *
     * This is safer than trying to guess every possible
     * UI event that could change the map dimensions.
     */
    let resizeObserver = null

    if (
      typeof ResizeObserver !==
      'undefined'
    ) {
      resizeObserver =
        new ResizeObserver(() => {
          console.log(
            '[LiveTripLocation][MAP] Container size changed.'
          )

          logMapSize(
            'ResizeObserver'
          )
        })

      resizeObserver.observe(
        map.getContainer()
      )
    }


    /*
     * Browser window resize fallback.
     */
    const handleWindowResize = () => {
      console.log(
        '[LiveTripLocation][MAP] Window resized.'
      )

      logMapSize(
        'window resize'
      )
    }

    window.addEventListener(
      'resize',
      handleWindowResize
    )


    return () => {
      cancelAnimationFrame(frame)

      clearTimeout(timeout)

      if (resizeObserver) {
        resizeObserver.disconnect()
      }

      window.removeEventListener(
        'resize',
        handleWindowResize
      )

      console.log(
        '[LiveTripLocation][MAP] Map instance cleanup.'
      )
    }
  }, [map])


  return null
}


/*
 * ============================================================
 * MAP FOLLOWER
 * ============================================================
 *
 * Keeps the map centred on the newest location.
 *
 * We intentionally do NOT recreate the MapContainer when
 * coordinates change.
 */

function MapFollower({ position }) {
  const map = useMap()

  useEffect(() => {
    if (!position) {
      console.log(
        '[LiveTripLocation][MAP] MapFollower: no position.'
      )

      return
    }


    console.log(
      '[LiveTripLocation][MAP] New location received by map.',
      {
        latitude:
          position.latitude,

        longitude:
          position.longitude,

        accuracy:
          position.accuracy,
      }
    )


    /*
     * Make sure Leaflet knows the container's current
     * dimensions before moving the map.
     */
    map.invalidateSize({
      animate: false,
    })


    map.flyTo(
      [
        position.latitude,
        position.longitude,
      ],
      Math.max(
        map.getZoom(),
        15
      ),
      {
        duration: 0.8,
      }
    )
  }, [
    map,
    position?.latitude,
    position?.longitude,
  ])

  return null
}


/*
 * ============================================================
 * DATE FORMATTER
 * ============================================================
 */

function formatLastUpdated(value) {
  if (!value) {
    return 'No location yet'
  }

  const date =
    new Date(value)

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return 'Unknown'
  }

  return date.toLocaleTimeString(
    [],
    {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }
  )
}


/*
 * ============================================================
 * LOCATION STATUS MESSAGE
 * ============================================================
 */

function getLocationStatusMessage(
  status,
  fallbackMessage
) {
  if (fallbackMessage) {
    return fallbackMessage
  }

  switch (status) {
    case 'NOT_SHARED':
      return 'No passenger is currently sharing live location.'

    case 'SHARING_STOPPED':
      return 'Live location sharing has been stopped.'

    case 'LOCATION_STALE':
      return 'The shared location has not been updated recently.'

    default:
      return 'Live vehicle location is currently unavailable.'
  }
}


/*
 * ============================================================
 * COMPONENT
 * ============================================================
 */

export default function LiveTripLocation({
  requestId,
  status,
  isPassenger = true,
}) {
  const [location, setLocation] =
    useState(null)

  const [locationStatus, setLocationStatus] =
    useState('NOT_SHARED')

  const [locationMessage, setLocationMessage] =
    useState('')

  const [sharingSummary, setSharingSummary] =
    useState(null)

  const [loading, setLoading] =
    useState(true)

  const [sharing, setSharing] =
    useState(false)

  const [permissionError, setPermissionError] =
    useState('')

  const [serverError, setServerError] =
    useState('')

  const [lastSent, setLastSent] =
    useState(null)

  const watchIdRef =
    useRef(null)

  const mountedRef =
    useRef(true)


  /*
   * ==========================================================
   * DEBUG: COMPONENT MOUNT
   * ==========================================================
   */

  useEffect(() => {
    console.log(
      '[LiveTripLocation] Component mounted.',
      {
        requestId,
        status,
        isPassenger,
      }
    )

    return () => {
      console.log(
        '[LiveTripLocation] Component unmounted.',
        {
          requestId,
        }
      )
    }
  }, [])


  /*
   * ==========================================================
   * TRACKING PERMISSION
   * ==========================================================
   */

  const trackingAllowed = [
    'ASSIGNED',
    'DRIVER_SPOTTED',
    'BOARDED_WAITING',
  ].includes(status)


  /*
   * ==========================================================
   * STOP BROWSER GPS WATCHER
   * ==========================================================
   */

  function stopWatching() {
    if (
      watchIdRef.current !== null &&
      navigator.geolocation
    ) {
      console.log(
        '[LiveTripLocation][GPS] Clearing GPS watcher.',
        {
          watchId:
            watchIdRef.current,
        }
      )

      navigator.geolocation.clearWatch(
        watchIdRef.current
      )

      watchIdRef.current = null
    }
  }


  /*
   * ==========================================================
   * STOP SERVER LOCATION SHARING
   * ==========================================================
   */

  async function stopSharing() {
    console.log(
      '[LiveTripLocation][GPS] Stopping location sharing.',
      {
        requestId,
      }
    )

    stopWatching()

    setSharing(false)

    try {
      const response =
        await stopTripLocation(
          requestId
        )

      console.log(
        '[LiveTripLocation][GPS] Location sharing stopped on server.',
        {
          requestId,
          response,
        }
      )
    } catch (error) {
      console.error(
        '[LiveTripLocation][GPS] Failed to stop server sharing.',
        {
          requestId,
          error,
          response:
            error?.response?.data,
        }
      )
    }

    if (
      mountedRef.current
    ) {
      await loadLocation()
    }
  }


  /*
   * ==========================================================
   * SEND GPS LOCATION
   * ==========================================================
   */

  async function sendLocation(
    position
  ) {
    const latitude =
      position.coords.latitude

    const longitude =
      position.coords.longitude

    const accuracy =
      position.coords.accuracy


    console.log(
      '[LiveTripLocation][GPS] GPS position received.',
      {
        requestId,
        latitude,
        longitude,
        accuracy,
      }
    )


    try {
      console.log(
        '[LiveTripLocation][API] Sending location to Laravel.',
        {
          requestId,
          latitude,
          longitude,
          accuracy,
        }
      )


      const response =
        await updateTripLocation(
          requestId,
          {
            latitude,
            longitude,
            accuracy,
          }
        )


      console.log(
        '[LiveTripLocation][API] Location update successful.',
        {
          requestId,
          response,
        }
      )


      if (
        !mountedRef.current
      ) {
        console.log(
          '[LiveTripLocation][GPS] Component no longer mounted. Ignoring GPS response.'
        )

        return
      }


      const now =
        new Date()


      setLastSent(now)


      setLocation({
        latitude,
        longitude,
        accuracy,

        last_updated_at:
          now.toISOString(),
      })


      setLocationStatus(
        'LIVE'
      )


      setLocationMessage(
        'Live vehicle location is available.'
      )


      setServerError('')
    } catch (error) {
      console.error(
        '[LiveTripLocation][API] Failed to send GPS location.',
        {
          requestId,

          error,

          status:
            error?.response?.status,

          response:
            error?.response?.data,
        }
      )


      if (
        !mountedRef.current
      ) {
        return
      }


      setServerError(
        error?.response?.data?.message ||
        'Unable to send your location.'
      )
    }
  }


  /*
   * ==========================================================
   * START GPS TRACKING
   * ==========================================================
   */

  function startSharing() {
    console.log(
      '[LiveTripLocation][GPS] Start sharing requested.',
      {
        requestId,
        status,
        trackingAllowed,
        hasGeolocation:
          Boolean(
            navigator.geolocation
          ),
      }
    )


    setPermissionError('')
    setServerError('')


    if (
      !navigator.geolocation
    ) {
      console.error(
        '[LiveTripLocation][GPS] Browser does not support geolocation.'
      )

      setPermissionError(
        'Your browser does not support location services.'
      )

      return
    }


    stopWatching()


    setSharing(true)


    console.log(
      '[LiveTripLocation][GPS] Starting browser watchPosition.'
    )


    const watchId =
      navigator.geolocation.watchPosition(
        (position) => {
          console.log(
            '[LiveTripLocation][GPS] watchPosition success.',
            {
              latitude:
                position.coords.latitude,

              longitude:
                position.coords.longitude,

              accuracy:
                position.coords.accuracy,
            }
          )

          sendLocation(
            position
          )
        },

        (error) => {
          console.error(
            '[LiveTripLocation][GPS] watchPosition error.',
            {
              code:
                error.code,

              message:
                error.message,

              requestId,
            }
          )


          if (
            !mountedRef.current
          ) {
            return
          }


          setSharing(false)


          switch (
            error.code
          ) {
            case error.PERMISSION_DENIED:
              setPermissionError(
                'Location permission was denied. Please allow location access in your browser settings.'
              )
              break

            case error.POSITION_UNAVAILABLE:
              setPermissionError(
                'Your location is currently unavailable. Please check your GPS/location settings.'
              )
              break

            case error.TIMEOUT:
              setPermissionError(
                'Getting your location timed out. Please try again.'
              )
              break

            default:
              setPermissionError(
                'Unable to access your location.'
              )
          }


          stopWatching()
        },

        {
          enableHighAccuracy:
            true,

          maximumAge:
            5000,

          timeout:
            15000,
        }
      )


    watchIdRef.current =
      watchId


    console.log(
      '[LiveTripLocation][GPS] GPS watcher started.',
      {
        watchId,
      }
    )
  }


  /*
   * ==========================================================
   * LOAD LOCATION FROM LARAVEL
   * ==========================================================
   */

  async function loadLocation() {
    console.log(
      '[LiveTripLocation][API] Loading trip location.',
      {
        requestId,
      }
    )


    try {
      const response =
        await getTripLocation(
          requestId
        )


      console.log(
        '[LiveTripLocation][API] Trip location response received.',
        {
          requestId,
          response,
        }
      )


      if (
        !mountedRef.current
      ) {
        console.log(
          '[LiveTripLocation][API] Component unmounted. Ignoring response.'
        )

        return
      }


      const nextLocation =
        response?.data ?? null

      const nextStatus =
        response?.location_status ||
        'NOT_SHARED'


      console.log(
        '[LiveTripLocation][STATE] Updating location state.',
        {
          requestId,

          hasLocation:
            Boolean(
              nextLocation
            ),

          locationStatus:
            nextStatus,

          location:
            nextLocation,

          sharingSummary:
            response?.sharing_summary,
        }
      )


      setLocation(
        nextLocation
      )


      setLocationStatus(
        nextStatus
      )


      setLocationMessage(
        getLocationStatusMessage(
          nextStatus,
          response?.message
        )
      )


      setSharingSummary(
        response?.sharing_summary ?? null
      )


      setServerError('')
    } catch (error) {
      console.error(
        '[LiveTripLocation][API] Failed to load trip location.',
        {
          requestId,

          error,

          status:
            error?.response?.status,

          response:
            error?.response?.data,
        }
      )


      if (
        !mountedRef.current
      ) {
        return
      }


      setServerError(
        error?.response?.data?.message ||
        'Unable to load live vehicle location.'
      )
    } finally {
      if (
        mountedRef.current
      ) {
        setLoading(false)
      }
    }
  }


  /*
   * ==========================================================
   * INITIAL LOAD + POLLING
   * ==========================================================
   */

  useEffect(() => {
    console.log(
      '[LiveTripLocation][LIFECYCLE] Starting location polling.',
      {
        requestId,
      }
    )


    mountedRef.current =
      true

    setLoading(true)


    loadLocation()


    const interval =
      setInterval(() => {
        console.log(
          '[LiveTripLocation][POLL] 10-second location refresh.',
          {
            requestId,
          }
        )

        loadLocation()
      }, 10000)


    return () => {
      console.log(
        '[LiveTripLocation][LIFECYCLE] Cleaning up polling.',
        {
          requestId,
        }
      )


      mountedRef.current =
        false

      clearInterval(
        interval
      )

      stopWatching()
    }
  }, [requestId])


  /*
   * ==========================================================
   * TERMINAL TRIP STATUS
   * ==========================================================
   */

  useEffect(() => {
    console.log(
      '[LiveTripLocation][STATUS] Trip status changed.',
      {
        requestId,
        status,
        trackingAllowed,
      }
    )


    if (
      status === 'COMPLETED' ||
      status === 'REJECTED' ||
      status === 'CANCELLED'
    ) {
      console.log(
        '[LiveTripLocation][STATUS] Terminal status detected. Stopping sharing.',
        {
          requestId,
          status,
        }
      )

      stopSharing()
    }
  }, [status])


  /*
   * ==========================================================
   * DO NOT DISPLAY BEFORE ASSIGNMENT
   * ==========================================================
   */

  if (
    status === 'PENDING' ||
    status === 'PENDING_LINE_MANAGER' ||
    status === 'PENDING_ADMIN' ||
    status === 'APPROVED'
  ) {
    console.log(
      '[LiveTripLocation][UI] Tracking hidden because trip is not assigned.',
      {
        requestId,
        status,
      }
    )

    return null
  }


  /*
   * ==========================================================
   * RENDER
   * ==========================================================
   */

  return (
    <div className="bg-surface border border-border-subtle rounded-card shadow-card overflow-hidden">

      {/* =====================================================
          HEADER
          ===================================================== */}

      <div className="px-4 py-3 border-b border-border-subtle bg-surface-muted">

        <div className="flex items-center justify-between gap-3">

          <div className="flex items-center gap-2">

            <div className="w-8 h-8 rounded-xl bg-brand-green-50 text-brand-green flex items-center justify-center">

              <Navigation
                size={15}
              />

            </div>


            <div>

              <h3 className="text-sm font-semibold text-ink-900">
                Live Vehicle Location
              </h3>

              <p className="text-2xs text-ink-400">
                Passenger-assisted tracking
              </p>

            </div>

          </div>


          {locationStatus === 'LIVE' &&
            location && (

            <div className="flex items-center gap-1.5 text-2xs font-medium text-brand-green">

              <span className="w-2 h-2 rounded-full bg-brand-green animate-pulse" />

              Live

            </div>

          )}

        </div>

      </div>


      {/* =====================================================
          LOADING
          ===================================================== */}

      {loading &&
        !location && (

        <div className="p-8 text-center">

          <RefreshCw
            size={25}
            className="mx-auto text-ink-300 animate-spin mb-3"
          />

          <p className="text-sm font-semibold text-ink-700">
            Checking vehicle location
          </p>

          <p className="text-xs text-ink-400 mt-1">
            Looking for an active location shared by a passenger.
          </p>

        </div>

      )}


      {/* =====================================================
          LIVE MAP
          ===================================================== */}

      {!loading &&
        location &&
        locationStatus === 'LIVE' && (

        <div className="relative h-[300px] sm:h-[380px]">

          <MapContainer
            center={[
              location.latitude,
              location.longitude,
            ]}
            zoom={15}
            scrollWheelZoom={false}
            className="w-full h-full"
          >

            <TileLayer
              attribution="&copy; OpenStreetMap contributors"
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />


            {/* Critical map resize handler */}
            <MapReadyHandler />


            {/* Follow newest GPS position */}
            <MapFollower
              position={location}
            />


            <Marker
              position={[
                location.latitude,
                location.longitude,
              ]}
              icon={vehicleIcon}
            >

              <Popup>

                <strong>
                  GreenFleet Vehicle
                </strong>

                <br />

                Last updated:{' '}

                {formatLastUpdated(
                  location.last_updated_at
                )}

              </Popup>

            </Marker>


            {location.accuracy && (

              <Circle
                center={[
                  location.latitude,
                  location.longitude,
                ]}
                radius={
                  location.accuracy
                }
                pathOptions={{
                  fillOpacity: 0.08,
                }}
              />

            )}

          </MapContainer>


          {/* Map status */}

          <div className="absolute left-3 bottom-3 z-[1000] bg-white/95 backdrop-blur border border-border-subtle rounded-xl shadow-sm px-3 py-2">

            <div className="flex items-center gap-2">

              <LocateFixed
                size={14}
                className="text-brand-green"
              />


              <div>

                <p className="text-2xs font-semibold text-ink-800">
                  Vehicle location
                </p>

                <p className="text-[10px] text-ink-400">

                  Updated{' '}

                  {formatLastUpdated(
                    location.last_updated_at
                  )}

                </p>

              </div>

            </div>

          </div>

        </div>

      )}


      {/* =====================================================
          NO LIVE LOCATION
          ===================================================== */}

      {!loading &&
        !location && (

        <div className="p-8 text-center">

          <div className="w-12 h-12 mx-auto rounded-2xl bg-ink-50 text-ink-300 flex items-center justify-center mb-3">

            <MapPin
              size={25}
            />

          </div>


          <p className="text-sm font-semibold text-ink-700">
            Location unavailable
          </p>


          <p className="text-xs text-ink-400 mt-1 max-w-sm mx-auto">
            {locationMessage}
          </p>


          {sharingSummary && (

            <div className="mt-4 inline-flex items-center gap-2 text-2xs text-ink-400 bg-surface-muted border border-border-subtle rounded-xl px-3 py-2">

              <LocateFixed
                size={12}
              />

              <span>

                {sharingSummary.active_count > 0
                  ? `${sharingSummary.active_count} passenger${sharingSummary.active_count === 1 ? '' : 's'} currently sharing`
                  : `${sharingSummary.total_passengers} passenger${sharingSummary.total_passengers === 1 ? '' : 's'} on this assignment`
                }

              </span>

            </div>

          )}

        </div>

      )}


      {/* =====================================================
          STALE LOCATION
          ===================================================== */}

      {!loading &&
        !location &&
        locationStatus ===
          'LOCATION_STALE' && (

        <div className="px-4 pb-4">

          <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-3">

            <RefreshCw
              size={14}
              className="shrink-0 mt-0.5"
            />

            <span>
              The vehicle's last shared location is no longer recent enough to display as live.
            </span>

          </div>

        </div>

      )}


      {/* =====================================================
          LOCATION SOURCE
          ===================================================== */}

      {location?.source_staff?.name && (

        <div className="px-4 py-3 border-t border-border-subtle">

          <div className="flex items-center justify-between gap-3">

            <div>

              <p className="text-2xs uppercase tracking-wider font-semibold text-ink-300">
                Location source
              </p>

              <p className="text-xs font-medium text-ink-700 mt-0.5">
                {location.source_staff.name}'s device
              </p>

            </div>


            {location.accuracy && (

              <p className="text-2xs text-ink-400">
                ±{Math.round(location.accuracy)}m
              </p>

            )}

          </div>

        </div>

      )}


      {/* =====================================================
          PASSENGER GPS CONTROLS
          ===================================================== */}

      {isPassenger &&
        trackingAllowed && (

        <div className="px-4 py-4 border-t border-border-subtle">

          {!sharing ? (

            <div>

              <div className="flex items-start gap-3 mb-3">

                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">

                  <LocateFixed
                    size={15}
                  />

                </div>


                <div>

                  <p className="text-sm font-semibold text-ink-800">
                    Help track the vehicle
                  </p>

                  <p className="text-xs text-ink-400 mt-0.5 leading-relaxed">
                    If you're inside the assigned vehicle,
                    you can share your phone's location.
                    This lets GreenFleet show the vehicle
                    location to the other passengers.
                  </p>

                </div>

              </div>


              <button
                type="button"
                onClick={
                  startSharing
                }
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-green text-white rounded-btn px-4 py-2.5 text-sm font-semibold hover:opacity-90 transition-opacity"
              >

                <Navigation
                  size={14}
                />

                Enable Live Location

              </button>

            </div>

          ) : (

            <div className="flex items-center justify-between gap-3">

              <div className="flex items-center gap-2">

                <span className="w-2.5 h-2.5 rounded-full bg-brand-green animate-pulse" />


                <div>

                  <p className="text-xs font-semibold text-ink-800">
                    Your location is being shared
                  </p>

                  <p className="text-2xs text-ink-400">

                    Last sent{' '}

                    {lastSent
                      ? lastSent.toLocaleTimeString(
                          [],
                          {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit',
                          }
                        )
                      : 'just now'}

                  </p>

                </div>

              </div>


              <button
                type="button"
                onClick={
                  stopSharing
                }
                className="text-xs font-medium text-red-500 hover:text-red-700"
              >
                Stop sharing
              </button>

            </div>

          )}


          {permissionError && (

            <div className="mt-3 flex items-start gap-2 text-xs text-red-600 bg-red-50 border border-red-200 rounded-xl p-3">

              <AlertCircle
                size={14}
                className="shrink-0 mt-0.5"
              />

              <span>
                {permissionError}
              </span>

            </div>

          )}


          {serverError && (

            <div className="mt-3 flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-xl p-3">

              <RefreshCw
                size={14}
                className="shrink-0 mt-0.5"
              />

              <span>
                {serverError}
              </span>

            </div>

          )}

        </div>

      )}

    </div>
  )
}