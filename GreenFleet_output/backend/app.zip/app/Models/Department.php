<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Department extends Model
{
    protected $fillable = [
        'name',
        'code',
        'line_manager_name',
        'line_manager_email'
    ];

    public function users(): HasMany
    {
        return $this->hasMany(User::class);
    }
}